from django.shortcuts import render, redirect ,get_object_or_404
from django.core.handlers.wsgi import WSGIRequest
from django.contrib.auth.forms import UserCreationForm
from  .froms import RegisterForm ,LoginForm
from django.contrib.auth import authenticate , login , logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages

def register_view(request: WSGIRequest):
    if request.method == "POST":
        form = RegisterForm(data=request.POST)
        if form.is_valid():
            user =form.save()
            messages.success(request , f"{user.username}Siz ro'yxatdan muvofaqqiyatli o'tdingiz!")
            return redirect("login")

    context = {
            "form": RegisterForm()
    }
    return render(request, "user/register.html", context)

def login_view(request):
    if request.method == "POST":
        form =LoginForm(data =request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request ,user)
            next_page = request.META.get("HTTP_REFERER")
            if next_page :
                page =next_page.split("=")[-1] if   "=" in next_page else 'home'
            else:
                pass
            return redirect(page)
    context = {
            "form" :LoginForm()
        }
    return render(request,"user/login.html", context)

@login_required
def logout_view(request):
    logout(request)
    return redirect("login")

@login_required
def user_profile(request, username):
    user = get_object_or_404(User, username=username)
    context = {
        "user" : user       
    }
    return render(request, 'user/profile.html', context)

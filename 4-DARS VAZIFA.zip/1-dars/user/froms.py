from django.contrib.auth.forms import AuthenticationForm , UserCreationForm
from django.contrib.auth.models import User
from django import forms

class RegisterForm(UserCreationForm):
    class Meta:
        username = forms.CharField(max_length=150,widget=forms.TextInput(attrs={
            "id" :"username",
            "name" : "username"
        }))
        model = User
        fields =('username' , 'email')

class LoginForm(AuthenticationForm):
    username =forms.CharField(max_length=150,widget=forms.TextInput(attrs={
        "id" :"username"
    }))
    password =forms.CharField(max_length=150,widget=forms.TextInput(attrs={
        "id" :"username"
    }))
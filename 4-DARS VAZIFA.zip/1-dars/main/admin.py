from django.contrib import admin
from .models import HeroSlider,Category,Products

admin.site.register(HeroSlider)
admin.site.register(Category)
admin.site.register(Products)

from django.urls import path
from .views import index,add_product,product_detail,product_update,product_delete

urlpatterns = [
    path('', index, name="home"),
    path('add/', add_product, name="add_product"),
    path('<int:pk>/', product_detail, name='product_detail'),
    path('update/<int:pk>/', product_update, name='product_update'),
    path('delete/<int:pk>/', product_delete, name='product_delete'),
]

from django import forms
from .models import Products


class ProductForms(forms.ModelForm):
    class Meta:
        model = Products
        fields = "__all__"

        labels = {
            "title": "Nomi",
            "description": "Matni",
            "price": "Narxi",
            "category": "Kategoriya",
        }

        help_texts = {
            "title": "Mahsulot nomini kiriting",
        }

        error_messages = {
            "title": {
                "required": "Nomi kiritish shart!",
                "max_length": "Nomi juda uzun!",
            },
            "price": {
                "required": "Narx kiritish shart!",
            },
        }

        widgets = {
            "title": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Mahsulot nomi"
            }),
            "description": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 4
            }),
            "price": forms.NumberInput(attrs={
                "class": "form-control"
            }),
            "category": forms.Select(attrs={
                "class": "form-select"
            }),
        }

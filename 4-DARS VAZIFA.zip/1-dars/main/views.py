from django.core.handlers.wsgi import WSGIRequest
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import permission_required ,login_required
from .models import HeroSlider, Category, Products
from .forms import ProductForms



def index(request: WSGIRequest):
    sliders = HeroSlider.objects.filter(published=True)
    categories = Category.objects.all()
    products = Products.objects.filter(is_active=True)

    context = {
        "title": "Abu_cafe",
        "sliders": sliders,
        "categories": categories,
        "products": products
    }
    return render(request, "index.html", context)

@permission_required('main.add_product')
def add_product(request: WSGIRequest):
    form = ProductForms()
    if request.method == "POST":
        form = ProductForms(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect("home")

    context = {
        "form": form
    }
    return render(request, "main/add_product.html", context)
@login_required
def product_detail(request, pk):
    product = get_object_or_404(Products, pk=pk)

    context = {
        "product": product
    }
    return render(request, "main/detail.html", context)

@permission_required('main.change_product')
def product_update(request, pk):
    product = get_object_or_404(Products, pk=pk)

    if request.method == "POST":
        form = ProductForms(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect("product_detail", pk=product.pk)
    else:
        form = ProductForms(instance=product)

    context = {
        "form": form,
        "product": product
    }
    return render(request, "main/add_product.html", context)

@permission_required('main.delete_product')
def product_delete(request, pk):
    product = get_object_or_404(Products, pk=pk)

    if request.method == "POST":
        product.delete()
        return redirect("home")

    context = {
        "product": product
    }
    return render(request, "main/product_confirm_delete.html", context)
